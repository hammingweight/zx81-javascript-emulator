//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USERES("OfficeButton97.res");
USEPACKAGE("vcl50.bpi");
USEUNIT("..\OffBtn.pas");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
        return 1;
}
//---------------------------------------------------------------------------
