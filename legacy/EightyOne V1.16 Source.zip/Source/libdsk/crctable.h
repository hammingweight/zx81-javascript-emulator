
/* CRC table for 0x104C11DB7, bit reverse algorithm */
extern const unsigned long crc32r_table[256];
