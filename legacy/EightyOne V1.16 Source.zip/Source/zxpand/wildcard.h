/*
	Wilcard matching function.
*/

extern int wildcmp(const char *wild,const char *string);

